# Prompt pro Claude Code

> Zkopíruj celý blok níže a vlož ho Claude Codovi v repu `automationcost.io`.
> Složka `design_handoff_homepage_redesign/` musí být v kořeni repa (nebo kdekoli, na co Claude Code vidí).

---

Jsi v repu statického webu `automationcost.io` (GitHub Pages, žádný build/server).
Ve složce `design_handoff_homepage_redesign/` je **kompletně hotový redesign** — všechny stránky jsou finální a připravené k nasazení. Přečti si `design_handoff_homepage_redesign/README.md` — jsou tam věci, které se **nesmí** dotknout.

---

## Tvůj úkol: 2 věci

### 1. Nasadit hotový design (copy + commit)
Redesign je **hotov**. Tvoje práce = bezpečně vyměnit staré soubory v kořeni repa za nové z handoff složky.

**Vždy pracuj na nové větvi:**
```bash
git checkout -b redesign
```

**Pak prostě zkopíruj:**
```bash
cp design_handoff_homepage_redesign/index.html .
cp design_handoff_homepage_redesign/calculator.html .
cp design_handoff_homepage_redesign/compare.html .
cp design_handoff_homepage_redesign/limits.html .
cp design_handoff_homepage_redesign/tools.html .
cp design_handoff_homepage_redesign/theme.css .
cp design_handoff_homepage_redesign/n8n-pricing.html .
cp design_handoff_homepage_redesign/make-pricing.html .
cp design_handoff_homepage_redesign/zapier-pricing.html .
cp design_handoff_homepage_redesign/pipedream-pricing.html .
cp design_handoff_homepage_redesign/activepieces-pricing.html .
cp design_handoff_homepage_redesign/automatisch-pricing.html .
cp design_handoff_homepage_redesign/node-red-pricing.html .
cp design_handoff_homepage_redesign/privacy.html .
cp design_handoff_homepage_redesign/terms.html .
cp design_handoff_homepage_redesign/affiliate.html .
```

Po kopiích ověř akceptační checklist (viz README), commitni a počkej na merge od majitele.

**Tvrdá pravidla — nesahej na:**
- `<script>` bloky (data + logika kalkulačky)
- `id` atributy, `onclick`/`oninput`/`data-*` atributy
- `integrations.json`
- JSON-LD schema bloky

`git diff` na `<script>` blocích musí být prázdný.

---

### 2. Dopsat matematiku odhadu v kalkulačce (`estimateVolumeBudget`)
Toto je **jediná** věc, kde se píše nový kód.

Vizuální vrstva a háčky jsou **hotové** v `calculator.html`. Zbývá napsat jednu čistou funkci a jedno volání:

**Co dopsat** — v `<script>` bloku `calculator.html` najdi komentář:
```
// TODO (Claude Code): napsat estimateVolumeBudget()
```
A doplň funkci. Vstup má k dispozici globální stav:
- `selectedCompanySize` — `"solo" | "small" | "growing" | "midmarket" | "enterprise"`
- `selectedRole` — `"nocode" | "dev" | "ops" | "founder"`  
- `selectedWorkflow` — slug primárního workflow (z `WORKFLOWS` dat)
- `selectedWorkflows` — pole slugů (vícenásobný výběr z kroku 3)

Funkce vrací objekt s libovolnou kombinací klíčů:
```js
function estimateVolumeBudget() {
  // tvoje logika...
  return { ops: 12000, workflows: 6, budget: 80 }; // příklad
}
```

**Jak zavolat** — v `goStep(n)` přidej (volání je připraveno, jen odkomentuj nebo doplň):
```js
if (n === 4 && selectedCompanySize) {
  applyEstimate(estimateVolumeBudget());
}
```

`applyEstimate()` (hotová funkce) nastaví slidery, odkryje badge `#ops-auto` / `#wf-auto` / `#budget-auto` a banner `#estimate-note`.

**Referenční hodnoty pro matematiku:**

| Company size | Typické ops/měs | Workflows | Budget/měs |
|---|---|---|---|
| solo | 500–2 000 | 1–3 | 0–20 |
| small (2–10) | 2 000–10 000 | 3–8 | 20–60 |
| growing (11–50) | 10 000–50 000 | 5–15 | 50–150 |
| midmarket (51–200) | 50 000–200 000 | 10–30 | 100–400 |
| enterprise (200+) | 200 000+ | 20+ | 300+ |

Role může škálovat ops nahoru (dev/ops) nebo workflows nahoru (founder/nocode).
Workflow typ (z `selectedWorkflow`) může škálovat ops — `"ecommerce"` > `"notifications"` > `"sync"` atd. (data jsou v `WORKFLOWS` konstantě).

Po doplnění: projdi celý 5-krokový wizard, ověř že badge se zobrazí a skryje správně, affiliate tlačítka fungují.

---

## Akceptační checklist
- [ ] Kalkulačka: projde všechny 5 kroků, vrátí výsledky, affiliate odkazy fungují
- [ ] Estimate badge se zobrazí na kroku 4 a skryje po manuálním tažení slideru
- [ ] FAQ accordion, nav dropdown „Pricing Guides" fungují
- [ ] `compare.html` — všechny 3 pohledy (Tools / Plans / All Plans) fungují, mobilní layout je stacked bez scrollování
- [ ] `limits.html` filtr funguje
- [ ] Žádná chyba v konzoli
- [ ] `git diff` na `<script>` blocích = prázdný
- [ ] Stránky fungují na mobilu (otestuj v DevTools 390px)
