# Handoff — AutomationCost.io homepage redesign (Caret theme)

## TL;DR pro Claude Code
**Redesign je HOTOV.** Všechny stránky v této složce jsou finální verze připravené k nasazení — stačí je zkopírovat do kořene repa (viz `CLAUDE_CODE_PROMPT.md`). Tvoje jediná nová práce = dopsat matematiku `estimateVolumeBudget()` v kalkulačce (detaily v promptu).

Web je statický (GitHub Pages, žádný server). „Backend" kalkulačky = **client-side JS uvnitř `calculator.html`**. **NIKDY nesahej na `<script>` bloky, `id`, `onclick`, `data-*` ani na třídy, které přepíná JS.**

---

## Co přibylo / změnilo se od prvního zápisu tohoto README

Níže je přehled všeho, co bylo **dodělano po** prvním zápisu — aby bylo jasné, co je v souborech nové oproti starému kódu v repu.

### Kalkulačka (`calculator.html`)
- **Auto-advance na single-select krocích** — krok 1 (Company size) a krok 2 (Role) po kliknutí automaticky přejdou na další krok bez „Next" tlačítka. Tlačítka Next na těchto krocích jsou skryta.
- **Krok „Company size"** — přidán jako nový první krok wizardu (celkem 5 kroků). Globální stav `selectedCompanySize`.
- **Multi-select workflows** — krok 3 podporuje výběr více workflows; `selectedWorkflows` je pole.
- **`applyEstimate()` hook** — hotová funkce, které se předají `{ ops, workflows, budget }` a nastaví slidery + odkryje badge. Zbývá napsat `estimateVolumeBudget()` (viz prompt).

### Compare (`compare.html`)
- **Mobilní Compare Tools — kompletně přepracovaný** — na ≤620px se tabulka (vlastnost × nástroj) přestala zobrazovat jako horizontálně scrollovatelná matice a místo toho se přeformátuje do **svislých karet bez scrollování**: nahoře nástroje (grid), pak každá vlastnost = karta s hodnotami označenými názvem nástroje. Funguje pro 2 i více nástrojů.
- **`data-tool` atribut** na každé hodnotové buňce — CSS `::before { content: attr(data-tool) }` zobrazuje název nástroje jako label na mobilu.
- **`<span class="cmp-val">`** wrapper na každé hodnotě — pro správné zarovnání na mobilu.
- **Compare Plans** — slider, vítězná karta, caret cena ladder, sloupce plánů se na mobilu skládají čistě pod sebe.
- **Logo jako comparison symbol** — hero sekce na compare.html zobrazuje `make` `<` `n8n` s reálnými logy nástrojů jako operátor srovnání.

### Navigace + všechny stránky
- **Nav tap targety** — `.nav-bottom a` má min. 44px výšku (touch-friendly).
- **CTA řady** — `.cta-row > a` se na ≤520px skládají na celou šířku.
- **Tools.html** — `.tool-header` na mobilu: logo zarovnáno k názvu, tagline a badges tečou na celou šířku, CTA přes celou šířku; `.pros-cons` se skládá do 1 sloupce na ≤460px.
- **Všechny pricing stránky** — sjednocené okraje a kolabování mřížek.

---

---

## Přehled
- **Repo:** `matt03X/automationcost.io` (branch `master`)
- **Stack:** statické HTML stránky, každá má vlastní inline `<style>` a inline `<script>`. Žádný build, žádný bundler, žádný server. `.nojekyll` → GitHub Pages servíruje raw soubory.
- **Cíl redesignu:** povýšit vizuál na „Caret" identitu (zelený caret = nejlevnější/akce), profesionální typografie, lepší hierarchie a konverzní tah na funnel (homepage → Tool Finder).

## Fidelity: **HIGH-FIDELITY**
Přiložená `index.html` je finální vizuál (přesné barvy, fonty, spacing, komponenty). Ostatní stránky implementuj pixel-věrně podle stejných tokenů a komponentních pravidel.

---

## ⛔ CO SE NESMÍ DOTKNOUT (jinak se rozbije kalkulačka)
Tyto věci jsou „API" mezi markupem a logikou. Restyl je MUSÍ zachovat 1:1:

1. **Celé `<script>` bloky** v `calculator.html` (a kdekoli jinde). Obsahují data + algoritmus:
   - datové konstanty: `LOGOS`, `ROLE_WEIGHTS`, `TOOL_SCORES`, `WORKFLOWS`, `INTEGRATIONS`, `TOOLS` (plány, `affiliateUrl`, `hasAffiliate`, `overage`), `CALC_OPS_STEPS`, `CALC_WF_STEPS`
   - funkce: `goStep`, `selectRole`, `selectWorkflow`, `renderWorkflowGrid`, `renderBigDiagram`, `updateBudget`, `updateOpsDisplay`, `updateWfDisplay`, scoring/render výsledků, `toggleFaq`, dropdown handler
2. **Element `id`** (JS na ně cílí přes `getElementById`): `step-1..4`, `wp-1..4`, `wl-1..3`, `btn-next-1`, `btn-next-2`, `ops`, `workflows`, `budget`, `budget-note`, `integ-search`, `integ-selected`, `results-list`, `no-results-msg`, `profile-summary`, `step2-sub`, SVG `id` (`wf-svg-*`, `wf-big-svg`) atd.
3. **`onclick` / `oninput` atributy** v markupu (`selectRole(...)`, `selectWorkflow('...')`, `goStep(n)`, `updateBudget(this.value)`, `toggleFaq(this)` …).
4. **`data-*` atributy** (`data-role`, …) — čte je JS přes `dataset`.
5. **Názvy tříd, které JS přepíná přes `classList`** — NEPŘEJMENOVÁVAT, jen měnit jejich *vzhled* v CSS:
   `active`, `selected`, `done`, `open`, `top-pick`, `good-fit`, `has-selection`,
   `score-fill` + modifikátory `.green/.yellow/.red`, `match-badge` + `.great/.good/.ok/.poor`,
   `result-cost` + `.c-free/.c-cheap/.c-mid`, `why-item` + `.pro/.con`, `visit-btn.affiliate`.
6. **`integrations.json`** a affiliate URL — datová vrstva, needitovat.
7. **JSON-LD `<script type="application/ld+json">`** (SEO schema) — needitovat, případně jen rozšířit.

> Pravidlo palce: **HTML struktura + CSS = volné. Cokoli, co čte nebo přepíná JavaScript = zamčené.**

---

## Design tokeny — mapování staré → nové
Každá stránka má vlastní `:root`. Sjednoť je na tuto sadu (Caret kit). **Hlavní změna: accent = ZELENÁ, ne modrá.**

| Token | Staré | Nové | Pozn. |
|---|---|---|---|
| `--bg` | `#080c14` / `#0a0e17` | **`#0a0e17`** | sjednotit napříč |
| `--surface` | `#0f1623` / `#111827` | **`#111827`** | |
| `--surface2` | `#151e30` / `#1a2236` | **`#1a2236`** | |
| `--border` | `#1e2d45` / `#1f2d45` | **`#1f2d45`** | |
| `--border2` | `#243350` | **`#27375a`** | |
| `--text` | `#e8edf5` | `#e8edf5` | beze změny |
| `--text2` | `#a8b4cc` | `#a8b4cc` | |
| `--muted` | `#5a6a88` / `#6b7a99` | **`#6b7a99`** | |
| **`--accent`** | **`#2f6bff` (modrá)** | **`#10b981` (zelená)** | ⭐ klíčová změna |
| `--accent-br` | — | `#16d18c` | jasná zelená pro mark |
| `--accent-glow` | `rgba(47,107,255,.18)` | `rgba(16,185,129,.20)` | |
| `--accent-dim` | `rgba(47,107,255,.08)` | `rgba(16,185,129,.09)` | |
| `--ink` | — | `#04130d` | text na zeleném CTA |
| `--link` | (accent) | `#6f9bff` | modrá jen pro inline odkazy |
| `--radius` | `12px` / `10px` | `14px` | |
| `--radius-sm` | `8px` | `9px` | |

### ⚠️ Natvrdo zapsaná modrá (mimo proměnné)
V `calculator.html` je spousta `rgba(47,107,255, …)` napsaných napřímo (např. `.role-card.selected`, `.integ-tag`, hover stíny). Po změně `--accent` je **najdi a nahraď**:
`rgba(47,107,255,` → `rgba(16,185,129,`  (zachovej koncovou alfu).
Stejně tak případné `#2f6bff` v CSS pravidlech → `#10b981`. (Pozor: v `TOOLS`/JS NIC neměnit — jen v CSS.)

> Pozn.: zelená je **rezervovaná** pro „vítěze / nejlevnější / primární akci". Modrá zůstává max. na inline textové odkazy (`--link`). Žluté/červené stavové barvy v kalkulačce (`--yellow`, `--red`) ponech.

---

## Fonty
Nahraď font link na každé stránce:
```html
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Hanken+Grotesk:wght@500;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap" rel="stylesheet">
```
- **Plus Jakarta Sans** (`--font`) → veškerý text, nadpisy, UI. Plná česká diakritika.
- **Hanken Grotesk** (`--display`) → **logo wordmark** a **footer** (brandový hlas). Čistý, profesionální grotesk; plná diakritika.
- **JetBrains Mono** (`--mono`) → čísla, ceny, malé verzálkové labely, badge. Plná diakritika.

**Logo lockup (důležité):** mezera caret→wordmark = **8px** (`.logo-icon margin-right`), tracking wordmarku **−0.01em** (opticky těsný), font-weight 800, mark 26px. Barvy: `Automation` bílá · `Cost` zelená · `.io` muted/600.

## Pohyb — gradient + scroll reveal
- **Gradient:** akcent v hero (`<em>`) má green→mint přeliv (`linear-gradient(96deg,#16d18c,#2ee6a6,#10b981)` + `background-clip:text`). Pozadí `body::before` má bohatší zelené radiální glow. Použij střídmě — zelená zůstává rezervovaná.
- **Scroll reveal:** below-fold bloky mají `class="reveal"` (+ `data-d` pro stagger) a naskakují fade+slide při vstupu do viewportu; hero naskakuje při load. Hotové CSS+JS je v `theme.css`. **Vždy** za `prefers-reduced-motion: no-preference` a JS jen **přiappenduj** k existujícímu `<script>` (nikdy nepřepisuj).

## Typografický spacing systém (profi rytmus)
```css
body  { font-size:15.5px; line-height:1.7; letter-spacing:0.01em; word-spacing:0.04em; }
h1    { letter-spacing:-0.022em; word-spacing:-0.01em; }      /* velký displej se stahuje */
h2    { letter-spacing:-0.014em; }
h3,h4 { letter-spacing:-0.006em; word-spacing:0.04em; }       /* výrokové nadpisy dýchají */
p, li { line-height:1.6–1.78; }
.label / .mono caps { font-family:var(--mono); letter-spacing:0.10–0.16em; text-transform:uppercase; }
```
Velké nadpisy: `text-wrap: balance`. Odstavce: `text-wrap: pretty`. **Nikdy** nevynucuj `<br>` v dlouhém nadpisu (láme se to s `text-wrap: balance`) — místo toho omez `max-width` (např. `16ch`).

## Komponenty — co změnit (vzhled, ne strukturu)
- **Logo:** caret mark s **bílou** price-point tečkou (`<circle … fill="#fff">`), wordmark `Automation`**`Cost`**`.io` (`.io` v `--muted`).
- **Primary CTA (`.btn-primary`):** plná **zelená**, text `--ink`, glow stín. To je „akce/vítěz".
- **Stat čísla:** `--mono`, labely verzálky `--mono`.
- **Karty (`.cta-card`, …):** `--surface` + `1px --border`, hover `border-color: --accent` + jemný green glow, `translateY(-3px)`. Jednu „hlavní" kartu lze zvýraznit `.featured` (jemný zelený gradient).
- **Caret jako prvek:** v kalkulačce u `top-pick`/`tag-best` použij caret „‹" (zelený) jako vlajku nejlevnějšího; v řazení může fungovat jako operátor `n8n ‹ Make ‹ Zapier`.
- **FAQ / accordion:** beze změny chování (`toggleFaq`), jen vizuál — chevron rotace, hover `--accent`.

---

## 🧮 Calculator — nový krok „Company size" + auto-estimate hook (PRO CLAUDE CODE)
`calculator.html` je už přestylovaný a rozšířený o **nový první krok „Company size"** (wizard má teď 5 kroků). Matematika odhadu volume/budget **NENÍ** napsaná — je připravená jen **vizuální vrstva + jeden integrační bod**. Claude Code dodá pouze výpočet:

- **Nový stav:** `selectedCompanySize` (`"solo" | "small" | "growing" | "midmarket" | "enterprise"`) — nastavuje `selectCompanySize()`.
- **Multi-select workflows:** krok 3 je teď **vícenásobný výběr** — `selectedWorkflows` je pole id, `selectedWorkflow` zůstává = poslední vybraný (primární, čte ho scoring beze změny). Slidery se předvyplní **součtem** defaultů vybraných workflows. Pro přesnější scoring přes všechny vybrané může Claude Code upgradovat `computeMatchScore` na iteraci `selectedWorkflows` (volitelné).
- **Integrační funkce (jediné, co volat):**
  ```js
  // spočítej čísla z selectedCompanySize / selectedRole / selectedWorkflow, pak:
  applyEstimate({ ops: 12000, workflows: 6, budget: 80 }); // předej jen klíče, co chceš vyplnit
  ```
  `applyEstimate()` nastaví slidery na nejbližší krok (`CALC_OPS_STEPS` / `CALC_WF_STEPS` přes `findClosestIdx`), obnoví displeje a **odkryje** badge `#ops-auto` / `#wf-auto` / `#budget-auto` + banner `#estimate-note`.
- **Kde to zavolat:** typicky na začátku kroku 4 — v `goStep(n)` přidej `if (n === 4 && selectedCompanySize) applyEstimate(estimateVolumeBudget());` (tvoji čistou funkci `estimateVolumeBudget()` dopíšeš).
- **Skip = ruční režim:** když uživatel `applyEstimate` nezavoláš, badge i banner zůstanou skryté a slidery na statických defaultech — uživatel je nastaví sám. Žádná další práce.
- **Cross-page „Best for me" (calculator → compare):** kalkulačka na konci `renderResults()` ukládá lehký profil do `localStorage["ac_profile"]` = `{ ops, workflows, budget, hostPref, aiPref, role, companySize, workflowsSel, topTool, topPlan, ts }`. Stránka **`compare.html`** má v „Compare Plans" view toggle **„Best for me"** (`pcToggleBestForMe()`), který profil načte, předřadí doporučený nástroj (`topTool`), nastaví ops slider na uloženou hodnotu a zvýrazní nejlevnější plán + ukáže note. Když profil chybí, nabídne odkaz na finder. Čistě prezentační vrstva nad existující `pcRenderGrid` logikou — scoring beze změny. Pokud upravíš tvar profilu, drž klíče `ops` + `topTool` (slug z `TOOLS`).
- **Ruční tažení slideru** automaticky skryje jeho badge (a banner, když zmizí všechny) — řešeno, nesahat.
- **Workflow už dnes** předvyplňuje ops/workflows z `wf.defaultOps`/`wf.defaultWorkflows` (v `selectWorkflow`). Tvoje matematika to může nahradit/škálovat faktorem podle `selectedCompanySize`.
- **Pozor:** scoring (`computeMatchScore`, `TOOLS`, …) se NEMĚNÍ. Estimate jen plní vstupy, které scoring už čte.

---

## Rollout po stránkách (pořadí)
1. **`index.html`** — ✅ hotovo (přiložená referenční verze; nahraď kořenovou).
2. **`calculator.html`** — ✅ přestylováno + nový krok „Company size" + auto-estimate hook. Zbývá jen napsat matematiku `estimateVolumeBudget()` a zavolat `applyEstimate()` (viz výše). **Zbytek `<script>` se nedotýkat.** Otestuj celý 5-krokový flow a affiliate tlačítka.
3. **`compare.html`** — ✅ přestylováno (theme + funnel CTA). **`limits.html`** — ✅ přestylováno + funnel CTA + FAQPage schema (filtr/řazení JS nedotčené). **`tools.html`** — ✅ přestylováno + funnel CTA + ItemList schema. Pozn.: `badge-blue` je **informační** badge (AI nodes, Cloud only…) — přemapován na tlumenou modrou `#9fbcff` (z `--link` palety), NE na zelenou, aby zůstal odlišný od „winner" zelené.
4. **`*-pricing.html`** (n8n/make/zapier/pipedream/activepieces/automatisch/node-red) — ✅ všech 7 přestylováno (theme + funnel-fab CTA; JSON-LD FAQ schema ponecháno). Pozn.: existují **2 varianty struktury** — „bohatá" (n8n/automatisch/node-red, nav dropdown + page-hero) a „jednoduchá" (make/zapier/pipedream/activepieces). Obě sjednoceny na stejné tokeny/fonty.
5. **`privacy/terms/affiliate.html`** — ✅ přestylováno (tokeny + fonty + logo). Legal stránky, bez funnel CTA.

**Hotovo: všechny stránky webu jsou přestylované do Caret theme.** Zbývá pouze (volitelně) napsat matematiku `estimateVolumeBudget()` v kalkulačce (viz sekce výše) — vizuál i háčky jsou připravené.

Po každé stránce: `git diff` musí ukazovat **jen `<style>` / třídy / markup** — žádné změny ve `<script>` blocích.

## Akceptační checklist (nic se nerozbilo)
- [ ] Kalkulačka: projde všechny 4 kroky, vrátí výsledky, affiliate odkazy fungují.
- [ ] FAQ accordion se rozbaluje, nav dropdown „Pricing Guides" funguje.
- [ ] `compare.html` slidery/výběr nástrojů fungují; `limits.html` filtr funguje.
- [ ] Žádná chyba v konzoli.
- [ ] Žádné `rgba(47,107,255` ani `#2f6bff` nezůstaly v CSS (jen `--link` modrá u textových odkazů, pokud chceš).
- [ ] Diakritika renderuje (Plus Jakarta + JetBrains Mono).
- [ ] `git diff` na `<script>` blocích = prázdný.

---

## (Volitelné) Fáze 2 — funnel v hero
Až bude základní restyl hotový a otestovaný: homepage hero může přímo spouštět Tool Finder (výběr role = krok 1). To už **vyžaduje napojení na logiku kalkulačky** → dělej zvlášť, opatrně, znovupoužij existující funkce (`selectRole`, `goStep`) místo psaní nových. Detaily v `Homepage Blueprint.html` (přiložen).

## Soubory v balíčku
- `index.html` — finální drop-in homepage (reference + k nasazení).
- `theme.css` — kanonická sada tokenů + base (k vložení do `:root` / jako vzor).
- `Homepage Blueprint.html` — strategie, funnel a anotovaný plán (kontext „proč").
- `CLAUDE_CODE_PROMPT.md` — hotový prompt, který vlož Claude Codovi.
