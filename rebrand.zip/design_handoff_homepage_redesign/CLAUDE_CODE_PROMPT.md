# Prompt pro Claude Code — WizardCost rebrand + homepage

> Zkopíruj celý blok níže a vlož ho Claude Codovi v repu.
> Složka `design_handoff_homepage_redesign/` musí být v kořeni repa (nebo kdekoli, na co Claude Code vidí).

---

Jsi v repu statického webu (GitHub Pages, build přes `build.py`).
Ve složce `design_handoff_homepage_redesign/` je dodávka od designéra: **rebrand AutomationCost → WizardCost rodina + nová homepage wizardcost.com**. Tvoje role = zkontrolovat, nasadit, nerozbít backend.

**Vždy pracuj na nové větvi:**
```bash
git checkout -b rebrand-wizardcost
```

---

## Co je v dodávce

### 1. Nová homepage `wizardcost-homepage.html` → nasadit jako kořenový `index.html`
Rozcestník wizardů (WizardCost master brand, fialová). Před nasazením:
- **Přepiš preview odkazy na produkční** — místa jsou označená HTML komentáři `<!-- build.py: href → ... -->`:
  - `design_handoff_homepage_redesign/index.html` → `/automation/`
  - `design_handoff_homepage_redesign/affiliate.html` → `/automation/affiliate.html` (totéž privacy, terms)
- **Canonical, og:*, GA4 injektuj přes build.py** — v souboru schválně nejsou (komentář v `<head>` to říká). Doména: `https://wizardcost.com/`.
- **Favicon**: `favicon-wizardcost.svg` (fialový mark) → nasadit do kořene jako favicon homepage.
- Homepage **nemá žádné affiliate odkazy** — nic k injektování z `data/tools.json`.

### 2. Automation stránky (15 souborů) → `/automation/`
Všechny HTML soubory ve složce (kromě `wizardcost-homepage.html`) jsou aktuální verze automation webu. Změny od minulé dodávky:

**A. Rebrand (jen viditelný obsah):**
- Nav logo: nový mark (zelený caret + jiskra), wordmark `AutomationCost` bez `.io` + drobné „by WizardCost"
- `index.html`: sekce „Part of the Cost.io network" → „Part of WizardCost" (fialový mark, odkaz na homepage — přepiš href dle komentáře)
- Footer: `AutomationCost.io` → `AutomationCost`
- `favicon.svg`: nový zelený mark

**B. Prodejní prvky (z předchozí dávky, pokud ještě nemáš):**
- `index.html`: hero price-gap proof ($8 n8n < $124 Zapier)
- `compare.html`: winner banner s „Save $X/yr" pillem + trust mikrocopy
- 7 pricing stránek: hero affiliate CTA „Try X free →" (`rel="sponsored"`) + „Prices verified June 2026"

### ⚠️ Poctivé přiznání — co se dotklo `<script>` bloků
V `compare.html` jsou **presentational** změny uvnitř `<script>` (funkce `renderResults`):
- hodnoty v tabulce mají `data-tool` atribut a `<span class="cmp-val">` wrapper (kvůli mobilnímu stacked layoutu)
- winner banner počítá roční úsporu z `costs[]` a renderuje `.winner-save` pill

**`const TOOLS` data, affiliate URL ani scoring se NEZMĚNILY.** Zkontroluj diffem:
```bash
git diff main -- automation/compare.html | grep -A3 -B3 "affiliateUrl\|const TOOLS"
```
Pokud tvůj build injektuje affiliate z `data/tools.json`, ověř, že injection markery v HTML zůstaly netknuté.

### Co NESMÍŠ změnit
- `<head>` meta tagy automation stránek (canonical, og:url, og:image) — řeší build.py; pořád odkazují na automationcost.io, **přepneš je v build.py až při migraci domény**, ne v HTML
- GA4 snippet (G-6LGJVD931P) — injektuje build.py
- Žádné hardcoded affiliate URL — vše z `data/tools.json`

---

## Akceptační checklist
- [ ] Homepage: všechny odkazy vedou na `/automation/...`, žádný na `design_handoff_...`
- [ ] Homepage: GA4 + canonical injektované build.py, favicon fialový
- [ ] `/automation/`: nav logo nový mark + „by WizardCost" na všech 15 stránkách, žádné `.io` ve viditelném obsahu
- [ ] `/automation/compare.html`: všechny 3 pohledy fungují, winner banner ukazuje „Save $X/yr" pro n8n vs Zapier, mobilní stacked layout OK (DevTools 390px)
- [ ] Kalkulačka: 5 kroků projde, auto-advance na krocích 1–2, výsledky + affiliate odkazy fungují
- [ ] `git diff` na `<head>` blocích = prázdný; diff na `<script>` jen presentational změny popsané výše
- [ ] Žádná chyba v konzoli na žádné stránce
